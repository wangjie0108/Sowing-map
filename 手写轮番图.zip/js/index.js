window.onload = function () {
    bannerEffect();
}

function bannerEffect() {
    var banner = document.querySelector(".banner");
    var imgBox = banner.querySelector('ul:first-of-type');
    /* 获取第一个li */
    var first = imgBox.querySelector('li:first-of-type');
    /* 获取最后一个li */
    var last = imgBox.querySelector('li:last-of-type');
    /* 复制第一个插入 */
    imgBox.appendChild(first.cloneNode(true));
    imgBox.insertBefore(last.cloneNode(true), imgBox.firstChild);

    var lis = imgBox.querySelectorAll('li');
    var count = lis.length;
    var bannerWidth = banner.offsetWidth;
    imgBox.style.width = count * bannerWidth + 'px';
    for (var i = 0; i < lis.length; i++) {
        /* 设置每一个li的宽度*/
        lis[i].style.width = bannerWidth + 'px';
    }
    var index = 1;
    imgBox.style.left = -bannerWidth + 'px';
    window.onresize = function () {
        bannerWidth = banner.offsetWidth;
        imgBox.style.width = count * bannerWidth + 'px';
        for (var i = 0; i < lis.length; i++) {
            lis[i].style.width = bannerWidth + 'px';
        }
        imgBox.style.left = -index * bannerWidth + 'px';
    }

    /*实现点标记*/
    var setDian = function (index) {
        var dians = banner.querySelector("ul:last-of-type").querySelectorAll("li");
        /*先清除其它li元素的active样式*/
        for (var i = 0; i < dians.length; i++) {
            dians[i].classList.remove("active");
        }
        /*为当前li元素添加active样式*/
        dians[index - 1].classList.add("active");
    }
    var timerId;
    var startTime = function () {
        timerId = setInterval(function () {
            index++;
            imgBox.style.transition = 'left .5s';
            imgBox.style.left = -index * bannerWidth + 'px';
            setTimeout(function () {
                if (index == count - 1) {
                    index = 1;
                    imgBox.style.transition = 'none';
                    imgBox.style.left = -index * bannerWidth + 'px';
                }
            }, 500);
        }, 1000);
    }
    startTime();
    /* 手动轮番 */
    var startX, moveX, distanceX;
    /* 标记当前过渡效果是否已经执行完毕 */
    var isEnd = true;
    imgBox.addEventListener('touchstart', function (e) {
        console.log('touchstart');
        /* 清除定时器 */
        clearInterval(timerId);
        startX = e.targetTouches[0].clientX;
    });
    imgBox.addEventListener('touchmove', function (e) {
        if (isEnd == true) {
            console.log('touchmove');
            moveX = e.targetTouches[0].clientX;
            distanceX = moveX - startX;
            imgBox.style.transition = 'none';
            imgBox.style.left = (-index * bannerWidth + distanceX) + 'px';
        }
    });
    imgBox.addEventListener('touchend', function (e) {
        console.log('touchend');
        isEnd = false;
        if (Math.abs(distanceX) > 100) {
            /* 判断是向前翻还是向后翻 */
            if (distanceX > 0) {
                index--;
            } else {
                index++;
            }
            imgBox.style.transition = 'left .5s';
            imgBox.style.left = -index * bannerWidth + 'px';
        } else if (Math.abs(distanceX > 0)) {
            imgBox.style.transition = 'left .5s ease-in-out';
            imgBox.style.left = -index * bannerWidth + 'px';
        }
        /* 将上一次move产生的数据重置为0 */
        startX = 0;
        moveX = 0;
        distanceX = 0;
    });
    imgBox.addEventListener('webkitTransitionEnd', function (e) {
        if (index == count - 1) {
            index = 1;
            imgBox.style.transition = 'none';
            imgBox.style.left = -index * bannerWidth + 'px';
        } else if (index == 0) {
            index = count - 2;
            imgBox.style.transition = 'none';
            imgBox.style.left = -index * bannerWidth + 'px';
        }
        setDian(index);
        setTimeout(function () {
            isEnd = true;
            /*清除之前添加的定时器*/
            clearInterval(timerId);
            //重新开启定时器
            startTime();
        }, 100);
    });
}